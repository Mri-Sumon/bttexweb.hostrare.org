<h4>From: Website Feedback Form</h4>
<p><strong>Sender Name:</strong> {{ $data['name'] }}</p>
<h4>Message:</h4>
<p>{{ $data['message'] }}</p>