@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Create New User
                    <a href="{{URL::to('users')}}" class="btn btn-outline-secondary float-right">Back to List</a>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                        <form action="{{ route('users.store') }}" method="post" enctype="multipart/form-data">@csrf
                            <div class="form-group col-md-7">
                                <label for="exampleInputName" class="h6">Name</label>
                                <input type="text" class="form-control" id="name"  name="name" placeholder="Full Name">
                            </div>
                            <div class="form-group col-md-7">
                                <label for="exampleInputEmail" class="h6">Email</label>
                                <input type="text" class="form-control" id="email"  name="email" placeholder="Email ID">
                            </div>
                            <div class="form-group col-md-7">
                                <label for="exampleInputPhone" class="h6">Phone</label>
                                <input type="text" class="form-control" id="phone"  name="phone" placeholder="Phone No">
                            </div>
                            <div class="form-group col-md-7">
                                <label for="exampleInputPhone" class="h6">User Type</label>
                                <select class="form-control" name="utype">
                                    <option>Select</option>
                                    <option value="USR">User</option>
                                    <option value="ADM">Admin</option>
                                </select>
                                @error('utype')
                                    <p class="alert alert-danger" role="alert">{{$message}}</p>
                                @enderror
                            </div>
                            <div class="form-group col-md-7">
                                <label for="exampleInputPassword" class="h6">Password</label>
                                <input type="password" class="form-control" id="password"  name="password" placeholder="Password">
                            </div>
                            <button class="btn btn-primary btn-lg ml-3" type="submit">Save</button>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
